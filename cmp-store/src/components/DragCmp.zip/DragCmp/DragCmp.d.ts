import Vue from 'vue'

export declare class DragCmp extends Vue {
  static install (vue: typeof Vue): void
  critical: number
}