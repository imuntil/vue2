import DragCmp from './DragCmp'

DragCmp.install = function (Vue) {
  Vue.component('drag-cmp', DragCmp)
}

export default DragCmp